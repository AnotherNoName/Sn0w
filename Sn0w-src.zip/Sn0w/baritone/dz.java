/*
 * Decompiled with CFR 0.152.
 */
package baritone;

import baritone.cm;

final class dz {
    static final /* synthetic */ int[] a;

    static {
        a = new int[cm.a().length];
        try {
            dz.a[2] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            dz.a[0] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            dz.a[1] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
    }
}

