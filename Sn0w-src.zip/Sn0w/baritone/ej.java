/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  et
 *  fa
 */
package baritone;

import baritone.api.utils.Rotation;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class ej {
    final int a;
    final et a;
    final fa a;
    final Rotation a;

    public ej(int n2, et et2, fa fa2, Rotation rotation) {
        this.a = n2;
        this.a = et2;
        this.a = fa2;
        this.a = rotation;
    }
}

