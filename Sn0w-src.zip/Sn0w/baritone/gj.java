/*
 * Decompiled with CFR 0.152.
 */
package baritone;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class gj {
    public int a;
    public int b;
    public int c;
    public double a;

    public gj() {
        this.a();
    }

    public final void a() {
        this.a = 0;
        this.b = 0;
        this.c = 0;
        this.a = 1000000.0;
    }
}

