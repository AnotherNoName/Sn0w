/*
 * Decompiled with CFR 0.152.
 */
package baritone;

import baritone.api.utils.Rotation;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class co {
    public Rotation a;
    boolean a;

    public co() {
        this(null, false);
    }

    public co(Rotation rotation, boolean bl2) {
        this.a = rotation;
        this.a = bl2;
    }
}

