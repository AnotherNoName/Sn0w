/*
 * Decompiled with CFR 0.152.
 */
package baritone;

import baritone.api.utils.Helper;
import baritone.api.utils.IPlayerContext;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class fm
implements Helper {
    final IPlayerContext a;
    int a;

    fm(IPlayerContext iPlayerContext) {
        this.a = iPlayerContext;
    }
}

