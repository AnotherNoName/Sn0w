/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  fa
 */
package baritone;

import baritone.api.utils.BetterBlockPos;
import baritone.cj;
import baritone.ck;
import baritone.cp;
import baritone.dr;
import baritone.gj;

final class da
extends cp {
    @Override
    public final ck a(cj cj2, BetterBlockPos betterBlockPos) {
        return dr.a(cj2, betterBlockPos, fa.c);
    }

    @Override
    public final void a(cj cj2, int n2, int n3, int n4, gj gj2) {
        dr.a(cj2, n2, n3, n4, fa.c, gj2);
    }
}

