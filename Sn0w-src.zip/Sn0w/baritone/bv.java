/*
 * Decompiled with CFR 0.152.
 */
package baritone;

import baritone.api.selection.ISelection;
import java.util.Arrays;
import java.util.HashSet;
import java.util.function.Function;

/*
 * Duplicate member names - consider using --renamedupmembers true
 * Exception performing whole class analysis.
 */
final class bv
extends Enum<bv> {
    private static /* enum */ bv a;
    private static /* enum */ bv b;
    private static /* enum */ bv c;
    final Function<ISelection[], ISelection[]> a;
    private final String[] a;
    private static final /* synthetic */ bv[] a;

    public static bv[] values() {
        return (bv[])a.clone();
    }

    public static bv valueOf(String string) {
        return Enum.valueOf(bv.class, string);
    }

    private bv(Function<ISelection[], ISelection[]> function, String ... stringArray) {
        super(string, n2);
        this.a = function;
        this.a = stringArray;
    }

    public static bv a(String string) {
        for (bv bv2 : bv.values()) {
            String[] stringArray = bv2.a;
            int n2 = bv2.a.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (!stringArray[i2].equalsIgnoreCase(string)) continue;
                return bv2;
            }
        }
        return null;
    }

    public static String[] a() {
        HashSet<String> hashSet = new HashSet<String>();
        for (bv bv2 : bv.values()) {
            hashSet.addAll(Arrays.asList(bv2.a));
        }
        return hashSet.toArray(new String[0]);
    }

    private static /* synthetic */ ISelection[] a(ISelection[] iSelectionArray) {
        return new ISelection[]{iSelectionArray[0]};
    }

    /*
     * Exception decompiling
     */
    static {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.parse.expression.NewAnonymousArray.getDimSize(NewAnonymousArray.java:142)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.LambdaRewriter.isNewArrayLambda(LambdaRewriter.java:455)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.LambdaRewriter.rewriteDynamicExpression(LambdaRewriter.java:409)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.LambdaRewriter.rewriteDynamicExpression(LambdaRewriter.java:167)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.LambdaRewriter.rewriteExpression(LambdaRewriter.java:105)
         *     at org.benf.cfr.reader.bytecode.analysis.parse.rewriters.ExpressionRewriterHelper.applyForwards(ExpressionRewriterHelper.java:12)
         *     at org.benf.cfr.reader.bytecode.analysis.parse.expression.AbstractConstructorInvokation.applyExpressionRewriter(AbstractConstructorInvokation.java:65)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.LambdaRewriter.rewriteExpression(LambdaRewriter.java:103)
         *     at org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredAssignment.rewriteExpressions(StructuredAssignment.java:146)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.LambdaRewriter.rewrite(LambdaRewriter.java:88)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.rewriteLambdas(Op04StructuredStatement.java:1137)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:912)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }
}

