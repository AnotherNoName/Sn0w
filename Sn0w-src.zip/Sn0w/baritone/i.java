/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  et
 */
package baritone;

import baritone.api.utils.BetterBlockPos;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
final class i {
    final long a;
    final int a;
    final String a;
    final et a;

    private i(long l2, int n2, String string, et et2) {
        this.a = l2;
        this.a = n2;
        this.a = string;
        this.a = et2;
        System.out.println("Future inventory created " + l2 + " " + n2 + " " + string + " " + (Object)((Object)BetterBlockPos.from(et2)));
    }

    /* synthetic */ i(long l2, int n2, String string, et et2, byte by2) {
        this(l2, n2, string, et2);
    }
}

