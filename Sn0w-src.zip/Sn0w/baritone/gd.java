/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  axw
 *  it.unimi.dsi.fastutil.longs.Long2ObjectMap
 */
package baritone;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;

public interface gd {
    public Long2ObjectMap<axw> loadedChunks();
}

