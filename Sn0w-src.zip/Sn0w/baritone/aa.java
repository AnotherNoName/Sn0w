/*
 * Decompiled with CFR 0.152.
 */
package baritone;

import baritone.ab;
import baritone.ac;
import baritone.ad;
import baritone.ae;
import baritone.af;
import baritone.api.command.argparser.IArgParser;
import java.util.Arrays;
import java.util.List;

public final class aa {
    public static final List<IArgParser<?>> a = Arrays.asList(ae.a, af.a, ad.a, ac.a, ab.a);
}

