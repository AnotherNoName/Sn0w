/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  fa$a
 */
package baritone;

final class fg {
    static final /* synthetic */ int[] a;

    static {
        a = new int[fa.a.values().length];
        try {
            fg.a[fa.a.a.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            fg.a[fa.a.b.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            fg.a[fa.a.c.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
    }
}

