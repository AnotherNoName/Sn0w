/*
 * Decompiled with CFR 0.152.
 */
package baritone;

import java.net.URI;

public interface gf {
    public void openLink(URI var1);
}

