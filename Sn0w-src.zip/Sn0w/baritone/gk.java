/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  et
 */
package baritone;

import baritone.a;
import baritone.api.BaritoneAPI;
import baritone.api.pathing.calc.IPath;
import baritone.api.pathing.goals.Goal;
import baritone.dv;
import baritone.fn;

public abstract class gk
implements IPath {
    @Override
    public /* synthetic */ IPath staticCutoff(Goal object) {
        Goal goal = object;
        object = this;
        int n2 = (Integer)BaritoneAPI.getSettings().pathCutoffMinimumLength.value;
        if (object.length() < n2) {
            return object;
        }
        if (goal == null || goal.isInGoal(object.getDest())) {
            return object;
        }
        double d2 = (Double)BaritoneAPI.getSettings().pathCutoffFactor.value;
        int n3 = (int)((double)(object.length() - n2) * d2) + n2 - 1;
        return new dv((IPath)object, n3);
    }

    @Override
    public /* synthetic */ IPath cutoffAtLoadedChunks(Object object) {
        Object object2 = object;
        object = this;
        if (((Boolean)a.a().cutoffAtLoadBoundary.value).booleanValue()) {
            object2 = (fn)object2;
            for (int i2 = 0; i2 < object.positions().size(); ++i2) {
                et et2 = object.positions().get(i2);
                if (((fn)object2).a(et2.p(), et2.r())) continue;
                return new dv((IPath)object, i2);
            }
        }
        return object;
    }
}

