/*
 * Decompiled with CFR 0.152.
 */
package baritone;

import baritone.eu;

final class ep {
    static final /* synthetic */ int[] a;

    static {
        a = new int[eu.a().length];
        try {
            ep.a[2] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            ep.a[1] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            ep.a[0] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
    }
}

