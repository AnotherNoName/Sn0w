/*
 * Decompiled with CFR 0.152.
 */
package baritone;

import java.io.File;

public interface ga {
    public File getChunkSaveLocation();
}

