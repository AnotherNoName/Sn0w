/*
 * Decompiled with CFR 0.152.
 */
package baritone;

import baritone.em;

final class el {
    static final /* synthetic */ int[] a;

    static {
        a = new int[em.a().length];
        try {
            el.a[1] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            el.a[2] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            el.a[3] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
    }
}

