/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  ayf
 */
package baritone;

public interface ge {
    public ayf getChunkLoader();
}

