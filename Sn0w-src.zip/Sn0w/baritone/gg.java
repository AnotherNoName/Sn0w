/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  et
 */
package baritone;

public interface gg {
    public void setIsHittingBlock(boolean var1);

    public et getCurrentBlock();

    public void callSyncCurrentPlayItem();
}

