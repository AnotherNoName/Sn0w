/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  amy
 *  amz
 *  anh
 *  anm
 *  avj
 *  awt
 *  bcz
 *  et
 *  fa
 *  javax.annotation.Nullable
 */
package baritone;

import baritone.fn;
import javax.annotation.Nullable;

public final class fo
implements amy {
    private final fn a;

    fo(fn fn2) {
        this.a = fn2;
    }

    @Nullable
    public final avj r(et et2) {
        return null;
    }

    public final int b(et et2, int n2) {
        return 0;
    }

    public final awt o(et et2) {
        return this.a.a(et2.p(), et2.q(), et2.r());
    }

    public final boolean d(et et2) {
        return this.a.a(et2.p(), et2.q(), et2.r()).a() == bcz.a;
    }

    public final anh b(et et2) {
        return anm.f;
    }

    public final int a(et et2, fa fa2) {
        return 0;
    }

    public final amz N() {
        return this.a.a.N();
    }
}

