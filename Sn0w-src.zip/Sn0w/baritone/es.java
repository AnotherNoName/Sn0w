/*
 * Decompiled with CFR 0.152.
 */
package baritone;

interface es {
    public int a(int var1, int var2);

    public int a();
}

