/*
 * Decompiled with CFR 0.152.
 */
package baritone;

import baritone.aa;
import baritone.api.command.argparser.IArgParser;
import baritone.api.command.argparser.IArgParser$Stated;
import baritone.api.command.argparser.IArgParser$Stateless;
import baritone.api.command.argparser.IArgParserManager;
import baritone.api.command.argument.ICommandArgument;
import baritone.api.command.exception.CommandInvalidTypeException;
import baritone.api.command.exception.CommandNoParserForTypeException;
import baritone.api.command.registry.Registry;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class z
extends Enum<z>
implements IArgParserManager {
    public static final /* enum */ z a = new z("INSTANCE");
    private Registry<IArgParser> a = new Registry();
    private static final /* synthetic */ z[] a;

    public static z[] values() {
        return (z[])a.clone();
    }

    public static z valueOf(String string) {
        return Enum.valueOf(z.class, string);
    }

    private z() {
        aa.a.forEach(((Registry)((Object)this.a))::register);
    }

    @Override
    public final <T> IArgParser$Stateless<T> getParserStateless(Class<T> clazz) {
        return ((Registry)((Object)this.a)).descendingStream().filter(IArgParser$Stateless.class::isInstance).map(IArgParser$Stateless.class::cast).filter(iArgParser$Stateless -> iArgParser$Stateless.getTarget().isAssignableFrom(clazz)).findFirst().orElse(null);
    }

    @Override
    public final <T, S> IArgParser$Stated<T, S> getParserStated(Class<T> clazz, Class<S> clazz2) {
        return ((Registry)((Object)this.a)).descendingStream().filter(IArgParser$Stated.class::isInstance).map(IArgParser$Stated.class::cast).filter(iArgParser$Stated -> iArgParser$Stated.getTarget().isAssignableFrom(clazz)).filter(iArgParser$Stated -> iArgParser$Stated.getStateType().isAssignableFrom(clazz2)).map(IArgParser$Stated.class::cast).findFirst().orElse(null);
    }

    @Override
    public final <T> T parseStateless(Class<T> clazz, ICommandArgument iCommandArgument) {
        IArgParser$Stateless<T> iArgParser$Stateless = this.getParserStateless(clazz);
        if (iArgParser$Stateless == null) {
            throw new CommandNoParserForTypeException(clazz);
        }
        try {
            return iArgParser$Stateless.parseArg(iCommandArgument);
        }
        catch (Exception exception) {
            throw new CommandInvalidTypeException(iCommandArgument, clazz.getSimpleName());
        }
    }

    @Override
    public final <T, S> T parseStated(Class<T> clazz, Class<S> object, ICommandArgument iCommandArgument, S s2) {
        if ((object = this.getParserStated(clazz, (Class<S>)object)) == null) {
            throw new CommandNoParserForTypeException(clazz);
        }
        try {
            return object.parseArg(iCommandArgument, s2);
        }
        catch (Exception exception) {
            throw new CommandInvalidTypeException(iCommandArgument, clazz.getSimpleName());
        }
    }

    @Override
    public final Registry<IArgParser> getRegistry() {
        return this.a;
    }

    static {
        a = new z[]{a};
    }
}

