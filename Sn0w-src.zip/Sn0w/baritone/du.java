/*
 * Decompiled with CFR 0.152.
 */
package baritone;

import baritone.cm;

final class du {
    static final /* synthetic */ int[] a;

    static {
        a = new int[cm.a().length];
        try {
            du.a[0] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            du.a[1] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
    }
}

