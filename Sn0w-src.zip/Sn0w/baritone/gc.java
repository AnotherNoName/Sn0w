/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  awt
 */
package baritone;

public interface gc {
    public awt getAtPalette(int var1);

    public int[] storageArray();
}

