/*
 * Decompiled with CFR 0.152.
 */
package baritone;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
final class eu
extends Enum<eu> {
    public static final int a = 1;
    public static final int b = 2;
    public static final int c = 3;
    private static final /* synthetic */ int[] a;

    public static int[] a() {
        return (int[])a.clone();
    }

    static {
        a = new int[]{1, 2, 3};
    }
}

