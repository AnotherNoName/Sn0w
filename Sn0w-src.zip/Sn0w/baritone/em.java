/*
 * Decompiled with CFR 0.152.
 */
package baritone;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class em
extends Enum<em> {
    public static final int a = 1;
    public static final int b = 2;
    public static final int c = 3;
    public static final int d = 4;
    private static final /* synthetic */ int[] a;

    public static int[] a() {
        return (int[])a.clone();
    }

    static {
        a = new int[]{1, 2, 3, 4};
    }
}

