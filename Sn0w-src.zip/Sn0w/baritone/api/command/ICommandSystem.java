/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.command;

import baritone.api.command.argparser.IArgParserManager;

public interface ICommandSystem {
    public IArgParserManager getParserManager();
}

