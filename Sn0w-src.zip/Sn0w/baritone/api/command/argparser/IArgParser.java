/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.command.argparser;

public interface IArgParser<T> {
    public Class<T> getTarget();
}

