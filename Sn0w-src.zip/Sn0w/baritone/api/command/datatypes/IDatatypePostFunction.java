/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.command.datatypes;

public interface IDatatypePostFunction<T, O> {
    public T apply(O var1);
}

