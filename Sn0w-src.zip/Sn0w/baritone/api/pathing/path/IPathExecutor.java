/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.pathing.path;

import baritone.api.pathing.calc.IPath;

public interface IPathExecutor {
    public IPath getPath();

    public int getPosition();
}

