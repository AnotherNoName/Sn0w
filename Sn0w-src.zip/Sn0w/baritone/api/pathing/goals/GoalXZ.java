/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  bhe
 *  rk
 */
package baritone.api.pathing.goals;

import baritone.api.BaritoneAPI;
import baritone.api.pathing.goals.Goal;
import baritone.api.utils.BetterBlockPos;
import baritone.api.utils.SettingsUtil;

public class GoalXZ
implements Goal {
    private static final double SQRT_2 = Math.sqrt(2.0);
    private final int x;
    private final int z;

    public GoalXZ(int n2, int n3) {
        this.x = n2;
        this.z = n3;
    }

    public GoalXZ(BetterBlockPos betterBlockPos) {
        this.x = betterBlockPos.a;
        this.z = betterBlockPos.c;
    }

    @Override
    public boolean isInGoal(int n2, int n3, int n4) {
        return n2 == this.x && n4 == this.z;
    }

    @Override
    public double heuristic(int n2, int n3, int n4) {
        n3 = n4 - this.z;
        return GoalXZ.calculate(n2 -= this.x, n3);
    }

    public String toString() {
        return String.format("GoalXZ{x=%s,z=%s}", SettingsUtil.maybeCensor(this.x), SettingsUtil.maybeCensor(this.z));
    }

    public static double calculate(double d2, double d3) {
        double d4;
        double d5;
        double d6;
        double d7 = Math.abs(d2);
        if (d7 < (d6 = Math.abs(d3))) {
            d5 = d6 - d7;
            d4 = d7;
        } else {
            d5 = d7 - d6;
            d4 = d6;
        }
        return (d4 * SQRT_2 + d5) * (Double)BaritoneAPI.getSettings().costHeuristic.value;
    }

    public static GoalXZ fromDirection(bhe bhe2, float f2, double d2) {
        f2 = (float)Math.toRadians(f2);
        double d3 = bhe2.b - (double)rk.a((float)f2) * d2;
        double d4 = bhe2.d + (double)rk.b((float)f2) * d2;
        return new GoalXZ(rk.c((double)d3), rk.c((double)d4));
    }

    public int getX() {
        return this.x;
    }

    public int getZ() {
        return this.z;
    }
}

