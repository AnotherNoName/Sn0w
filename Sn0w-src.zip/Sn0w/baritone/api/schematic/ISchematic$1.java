/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  fa$a
 */
package baritone.api.schematic;

class ISchematic$1 {
    static final /* synthetic */ int[] $SwitchMap$net$minecraft$util$EnumFacing$Axis;

    static {
        $SwitchMap$net$minecraft$util$EnumFacing$Axis = new int[fa.a.values().length];
        try {
            ISchematic$1.$SwitchMap$net$minecraft$util$EnumFacing$Axis[fa.a.a.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            ISchematic$1.$SwitchMap$net$minecraft$util$EnumFacing$Axis[fa.a.b.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            ISchematic$1.$SwitchMap$net$minecraft$util$EnumFacing$Axis[fa.a.c.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
    }
}

