/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.process;

import baritone.api.process.IBaritoneProcess;

public interface IFarmProcess
extends IBaritoneProcess {
    public void farm();
}

