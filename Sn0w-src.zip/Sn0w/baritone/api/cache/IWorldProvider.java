/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.cache;

import baritone.api.cache.IWorldData;

public interface IWorldProvider {
    public IWorldData getCurrentWorld();
}

