/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  aip
 */
package baritone.api.cache;

import java.util.List;

public interface IRememberedInventory {
    public List<aip> getContents();

    public int getSize();
}

