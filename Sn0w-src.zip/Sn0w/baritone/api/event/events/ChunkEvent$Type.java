/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.event.events;

public enum ChunkEvent$Type {
    LOAD,
    UNLOAD,
    POPULATE_FULL,
    POPULATE_PARTIAL;

}

