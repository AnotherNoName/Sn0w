/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.event.events.type;

public interface ICancellable {
    public void cancel();

    public boolean isCancelled();
}

