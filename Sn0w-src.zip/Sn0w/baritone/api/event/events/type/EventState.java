/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.event.events.type;

public enum EventState {
    PRE,
    POST;

}

