/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.event.events;

public enum RotationMoveEvent$Type {
    MOTION_UPDATE,
    JUMP;

}

