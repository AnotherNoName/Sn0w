/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.event.events;

public enum TickEvent$Type {
    IN,
    OUT;

}

