/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.behavior;

import baritone.api.event.listener.AbstractGameEventListener;

public interface IBehavior
extends AbstractGameEventListener {
}

