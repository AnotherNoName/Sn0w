/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.utils;

class SettingsUtil$1 {
}

