/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  et
 */
package baritone.api.utils.interfaces;

public interface IGoalRenderPos {
    public et getGoalPos();
}

