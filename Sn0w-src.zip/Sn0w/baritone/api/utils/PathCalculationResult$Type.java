/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.utils;

public enum PathCalculationResult$Type {
    SUCCESS_TO_GOAL,
    SUCCESS_SEGMENT,
    FAILURE,
    CANCELLATION,
    EXCEPTION;

}

