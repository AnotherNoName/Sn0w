/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.utils;

import baritone.api.utils.Helper;

final class Helper$1
implements Helper {
    Helper$1() {
    }
}

