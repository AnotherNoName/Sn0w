/*
 * Decompiled with CFR 0.152.
 */
package baritone.api.utils.accessor;

public interface IItemStack {
    public int getBaritoneHash();
}

