/*
 * Decompiled with CFR 0.152.
 */
package org.json.simple;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class ItemList {
    private String sp = ",";
    List items = new ArrayList();

    public ItemList() {
    }

    public ItemList(String s2) {
        this.split(s2, this.sp, this.items);
    }

    public ItemList(String s2, String sp) {
        this.sp = s2;
        this.split(s2, sp, this.items);
    }

    public ItemList(String s2, String sp, boolean isMultiToken) {
        this.split(s2, sp, this.items, isMultiToken);
    }

    public List getItems() {
        return this.items;
    }

    public String[] getArray() {
        return (String[])this.items.toArray();
    }

    public void split(String s2, String sp, List append, boolean isMultiToken) {
        if (s2 == null || sp == null) {
            return;
        }
        if (isMultiToken) {
            StringTokenizer tokens = new StringTokenizer(s2, sp);
            while (tokens.hasMoreTokens()) {
                append.add(tokens.nextToken().trim());
            }
        } else {
            this.split(s2, sp, append);
        }
    }

    public void split(String s2, String sp, List append) {
        if (s2 == null || sp == null) {
            return;
        }
        int pos = 0;
        int prevPos = 0;
        do {
            prevPos = pos;
            if ((pos = s2.indexOf(sp, pos)) == -1) break;
            append.add(s2.substring(prevPos, pos).trim());
        } while ((pos += sp.length()) != -1);
        append.add(s2.substring(prevPos).trim());
    }

    public void setSP(String sp) {
        this.sp = sp;
    }

    public void add(int i2, String item) {
        if (item == null) {
            return;
        }
        this.items.add(i2, item.trim());
    }

    public void add(String item) {
        if (item == null) {
            return;
        }
        this.items.add(item.trim());
    }

    public void addAll(ItemList list) {
        this.items.addAll(list.items);
    }

    public void addAll(String s2) {
        this.split(s2, this.sp, this.items);
    }

    public void addAll(String s2, String sp) {
        this.split(s2, sp, this.items);
    }

    public void addAll(String s2, String sp, boolean isMultiToken) {
        this.split(s2, sp, this.items, isMultiToken);
    }

    public String get(int i2) {
        return (String)this.items.get(i2);
    }

    public int size() {
        return this.items.size();
    }

    public String toString() {
        return this.toString(this.sp);
    }

    public String toString(String sp) {
        StringBuffer sb = new StringBuffer();
        for (int i2 = 0; i2 < this.items.size(); ++i2) {
            if (i2 == 0) {
                sb.append(this.items.get(i2));
                continue;
            }
            sb.append(sp);
            sb.append(this.items.get(i2));
        }
        return sb.toString();
    }

    public void clear() {
        this.items.clear();
    }

    public void reset() {
        this.sp = ",";
        this.items.clear();
    }
}

