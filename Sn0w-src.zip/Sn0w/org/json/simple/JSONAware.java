/*
 * Decompiled with CFR 0.152.
 */
package org.json.simple;

public interface JSONAware {
    public String toJSONString();
}

