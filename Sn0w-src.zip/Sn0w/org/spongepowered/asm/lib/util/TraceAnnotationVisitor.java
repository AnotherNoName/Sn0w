/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.util;

import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.util.Printer;

public final class TraceAnnotationVisitor
extends AnnotationVisitor {
    private final Printer p;

    public TraceAnnotationVisitor(Printer p2) {
        this(null, p2);
    }

    public TraceAnnotationVisitor(AnnotationVisitor av2, Printer p2) {
        super(327680, av2);
        this.p = p2;
    }

    public void visit(String name, Object value) {
        this.p.visit(name, value);
        super.visit(name, value);
    }

    public void visitEnum(String name, String desc, String value) {
        this.p.visitEnum(name, desc, value);
        super.visitEnum(name, desc, value);
    }

    public AnnotationVisitor visitAnnotation(String name, String desc) {
        Printer p2 = this.p.visitAnnotation(name, desc);
        AnnotationVisitor av2 = this.av == null ? null : this.av.visitAnnotation(name, desc);
        return new TraceAnnotationVisitor(av2, p2);
    }

    public AnnotationVisitor visitArray(String name) {
        Printer p2 = this.p.visitArray(name);
        AnnotationVisitor av2 = this.av == null ? null : this.av.visitArray(name);
        return new TraceAnnotationVisitor(av2, p2);
    }

    public void visitEnd() {
        this.p.visitAnnotationEnd();
        super.visitEnd();
    }
}

